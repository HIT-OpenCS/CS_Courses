#include<stdio.h>
#include <stdlib.h>
int main()
{
    printf("Hello 1190300321֣�ɺ�");
    system("pause");
    return 0;
}