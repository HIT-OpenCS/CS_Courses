# python3.7
"""Collects all runners."""

from .stylegan_runner import StyleGANRunner

__all__ = ['StyleGANRunner']
