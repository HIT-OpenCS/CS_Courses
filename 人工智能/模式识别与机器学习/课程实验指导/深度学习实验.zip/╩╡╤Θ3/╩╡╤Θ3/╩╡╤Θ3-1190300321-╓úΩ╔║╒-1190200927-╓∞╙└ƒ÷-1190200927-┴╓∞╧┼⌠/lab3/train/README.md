四种网络的最优模型太大，不随文件上传，如需运行以下为百度网盘地址：

VGG：链接：https://pan.baidu.com/s/1XMD1wNlu6H_TJTerGjw48A 
提取码：xdu5

ResNet：链接：https://pan.baidu.com/s/1To_ylrzsuu6EsKUfutSp9g 
提取码：2vun

SE-ResNet：链接：https://pan.baidu.com/s/1NUkyI06lf03SO4_WGRmp6Q 
提取码：2lrh

Inception ResNet V2：链接：https://pan.baidu.com/s/1kjKTvJdktp8ZDHE9jMAMPQ 
提取码：5xqr

下载后放在本文件夹下即可。