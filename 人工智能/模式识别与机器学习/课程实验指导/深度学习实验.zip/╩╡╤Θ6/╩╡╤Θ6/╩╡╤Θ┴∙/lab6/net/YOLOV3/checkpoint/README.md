由于YOLO V3最佳模型较大，提供百度网盘下载地址如下：链接：https://pan.baidu.com/s/1zWFfMysvFsbH2rGozjlrWA 
提取码：35cu

下载后放在本文件夹即可。