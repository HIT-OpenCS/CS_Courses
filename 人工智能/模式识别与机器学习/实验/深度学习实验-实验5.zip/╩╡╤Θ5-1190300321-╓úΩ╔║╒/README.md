保存的最优模型都在./lab5/GAN/train 文件夹下

SeFa中的预训练模型不随代码上传，如需使用则下载后放在checkpoint文件夹